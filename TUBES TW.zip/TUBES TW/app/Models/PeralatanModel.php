<?php

namespace App\Models;

use CodeIgniter\Model;

class PeralatanModel extends Model
{
    protected $table = 'peralatan';
    protected $primaryKey = 'id';
    
    // Sesuaikan allowedFields dengan nama kolom di database
    protected $allowedFields = [
        'kode',
        'nama',
        'id_kategori',
        'ukuran',
        'stok',
        'keterangan'
    ];

    public function getAll()
    {
        return $this->select('peralatan.*, kategori.nama_kategori AS nama_kategori')
                    ->join('kategori', 'kategori.id = peralatan.id_kategori', 'left')
                    ->findAll();
    }

public function getStokRendah()
{
    return $this->select('peralatan.id, peralatan.kode, peralatan.nama, peralatan.ukuran, peralatan.stok, peralatan.keterangan')
                ->where('peralatan.stok <', 5)
                ->findAll();
}

}
