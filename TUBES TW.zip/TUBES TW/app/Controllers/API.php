<?php

namespace App\Controllers;

use App\Models\PeralatanModel;
use CodeIgniter\RESTful\ResourceController;

class API extends ResourceController
{
    protected $modelName = PeralatanModel::class;
    protected $format = 'json';

    public function index()
    {
        $data = $this->model->getAll();
        return $this->respond($data);
    }
    public function show($id = null)
    {
        $data = $this->model->find($id);
        if ($data) {
            return $this->respond($data);
        }
        return $this->failNotFound('Data not found');
    }
    public function create()
    {
        $input = $this->request->getJSON(true);
        $this->model->insert($input);
        return $this->respond(['message' => 'Data successfully added'], 201);
    }
    public function update($id = null)
    {
        $input = $this->request->getJSON(true);
        $this->model->update($id, $input);
        return $this->respond(['message' => 'Data successfully updated']); 
    }
    public function delete($id = null)
    {
        $this->model->delete($id);
        return $this->respond(['message' => 'Data successfully removed']); 
    }
}
