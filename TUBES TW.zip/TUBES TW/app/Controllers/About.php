<?php

namespace App\Controllers;

use App\Models\PeralatanModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $model = new PeralatanModel();

        $data['total'] = $model->countAll();
        $data['peralatan'] = $model->getAll();

        return view('dashboard', $data);
    }
}
