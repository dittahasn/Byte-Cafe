<?php

namespace App\Controllers;

use App\Models\UserModel;

class Signup extends BaseController
{
    public function index()
    {
        // Tampilkan form signup
        return view('auth/signup'); 
    }

    public function register()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $role     = $this->request->getPost('role'); // ambil dari input form

        $model = new UserModel();

        // Cek apakah username sudah ada
        if ($model->getUserByUsername($username)) {
            return redirect()->back()->with('error', 'Username sudah digunakan.');
        }

        // Insert data user baru (tanpa hash password)
        $model->insert([
            'username' => $username,
            'password' => $password,
            'role'     => $role
        ]);

        return redirect()->to('/login')->with('success', 'Pendaftaran berhasil, silakan login.');
    }
}
