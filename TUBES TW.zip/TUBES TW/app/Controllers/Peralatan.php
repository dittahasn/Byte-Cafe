<?php

namespace App\Controllers;

use App\Models\PeralatanModel;
use App\Models\KategoriModel;

class Peralatan extends BaseController
{
    public function index()
    {
        $peralatanModel = new PeralatanModel();

        $data['peralatan'] = $peralatanModel
            ->select('peralatan.*, kategori.nama_kategori AS nama_kategori')
            ->join('kategori', 'kategori.id = peralatan.id_kategori', 'left')
            ->findAll();

        return view('index', $data); // file: app/Views/index.php
    }

    public function create()
{
    $kategoriModel = new \App\Models\KategoriModel();
    $data['kategori'] = $kategoriModel->findAll();
    return view('peralatan_create', $data);
}

public function store()
{
    $model = new PeralatanModel();
    $model->insert([
        'kode' => $this->request->getPost('kode'),
        'nama' => $this->request->getPost('nama'),
        'ukuran' => $this->request->getPost('ukuran'),
        'stok' => $this->request->getPost('stok'),
        'keterangan' => $this->request->getPost('keterangan'),
        'id_kategori' => $this->request->getPost('id_kategori'),
    ]);

    return redirect()->to('/peralatan')->with('success', 'Peralatan berhasil ditambahkan.');
}

public function edit($id)
{
    $model = new PeralatanModel();
    $kategoriModel = new \App\Models\KategoriModel();
    $data['item'] = $model->find($id);
    $data['kategori'] = $kategoriModel->findAll();

    return view('peralatan_edit', $data);
}

public function update($id)
{
    $model = new PeralatanModel();
    $model->update($id, [
        'kode' => $this->request->getPost('kode'),
        'nama' => $this->request->getPost('nama'),
        'ukuran' => $this->request->getPost('ukuran'),
        'stok' => $this->request->getPost('stok'),
        'keterangan' => $this->request->getPost('keterangan'),
        'id_kategori' => $this->request->getPost('id_kategori'),
    ]);

    return redirect()->to('/peralatan')->with('success', 'Peralatan berhasil diperbarui.');
}

public function delete($id)
{
    $model = new PeralatanModel();
    $model->delete($id);

    return redirect()->to('/peralatan')->with('success', 'Peralatan berhasil dihapus.');
}

 public function cetak()
{
    $model = new PeralatanModel();

    $data['peralatan'] = $model
        ->select('peralatan.*, kategori.nama_kategori AS nama_kategori')
        ->join('kategori', 'kategori.id = peralatan.id_kategori', 'left')
        ->findAll();

    return view('cetak', $data); // File view: app/Views/cetak.php
}



}