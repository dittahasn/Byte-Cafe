<?php

namespace App\Controllers;

use App\Models\PeralatanModel;

class Dashboard extends BaseController
{
    public function index()
    {
        $peralatanModel = new PeralatanModel();

        $data['total'] = $peralatanModel->countAll();
        $data['peralatan'] = $peralatanModel->getStokRendah();

        return view('dashboard', $data);
    }
}
