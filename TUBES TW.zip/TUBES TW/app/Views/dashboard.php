<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #edf2ff, #ffffff);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .navbar {
      box-shadow: 0 2px 6px rgb(0 0 0 / 10%);
    }

    .title-section {
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    }

    .card-glass {
      background: #ffffffcc;
      backdrop-filter: blur(10px);
      border: none;
      border-radius: 20px;
      box-shadow: 0 6px 20px rgb(0 0 0 / 5%);
    }

    .total-card {
      background: #ffffffcc;
      backdrop-filter: blur(10px);
      border-radius: 20px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.05);
      transition: all 0.3s ease;
    }

    .total-card:hover {
      transform: translateY(-3px);
      background: #e7f0ff;
      box-shadow: 0 10px 30px rgba(0, 123, 255, 0.2);
    }

    .total-icon {
      font-size: 3rem;
      color: #0d6efd;
    }

    .equipment-card {
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .equipment-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 6px 20px rgb(0 0 0 / 10%);
    }

    .badge-low-stock {
      background: #dc3545;
      font-size: 0.85rem;
      padding: 6px 12px;
      border-radius: 999px;
      color: #ffffff;
    }

    .search-box {
      margin-bottom: 20px;
    }

    .search-box input {
      border-radius: 30px;
      padding: 10px 20px;
      box-shadow: 0 4px 12px rgb(0 0 0 / 5%);
    }

    .section-description {
      color: #6c757d;
      margin-bottom: 1.5rem;
    }

    .btn-gradient {
      background: linear-gradient(45deg, #0d6efd, #6610f2);
      color: white !important;
      border: none;
      border-radius: 12px;
      padding: 10px 20px;
      font-weight: 500;
      text-decoration: none;
      transition: all 0.3s ease;
      box-shadow: 0 4px 12px rgba(13, 110, 253, 0.25);
    }

    .btn-gradient:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(102, 16, 242, 0.35);
      color: #000000 !important;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand fw-bold text-uppercase" href="<?= base_url('/dashboard') ?>">
        Inventory App
      </a>
      <div class="ms-auto">
        <a href="<?= base_url('/logout') ?>" class="btn btn-outline-light">
          <i class="bi bi-box-arrow-right me-1"></i> Logout
        </a>
      </div>
    </div>
  </nav>

  <div class="container py-5">
    <!-- Header -->
    <div class="title-section mb-4">
      <h2 class="fw-bold mb-0"><i class="bi bi-speedometer2 me-2"></i> Dashboard</h2>
      <div class="d-flex gap-2 mt-3 mt-md-0 flex-wrap">
        <a href="<?= base_url('/peralatan') ?>" class="btn-gradient">
          <i class="bi bi-gear me-1"></i> Kelola Peralatan
        </a>
        <a href="<?= base_url('/cetak') ?>" class="btn-gradient">
          <i class="bi bi-printer-fill me-1"></i> Cetak
        </a>
      </div>
    </div>

    <!-- Summary Card -->
    <div class="row mb-4">
      <div class="col-12">
        <div class="total-card d-flex align-items-center justify-content-between p-4 flex-wrap">
          <div class="d-flex align-items-center">
            <i class="bi bi-box-seam total-icon me-4"></i>
            <div>
              <h5 class="fw-semibold mb-1">Total Peralatan</h5>
              <h1 class="text-primary display-4 mb-0"><?= $total; ?></h1>
            </div>
          </div>
          <div class="text-end mt-3 mt-md-0">
            <span class="text-muted"><i class="bi bi-clock-fill me-1"></i>Diperbarui secara real-time</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Search Box -->
    <div class="search-box">
      <input id="searchInput" type="text" class="form-control" placeholder="🔍 Cari peralatan berdasarkan nama, ukuran, atau kode...">
    </div>

    <!-- Section Description -->
    <div class="section-description">
      Berikut daftar peralatan yang tersedia. Peralatan yang stoknya rendah diberi label merah demi menjaga ketersediaan.
    </div>

    <!-- Peralatan Stok Rendah -->
    <div class="mb-3">
      <h4 class="mb-3 fw-semibold"><i class="bi bi-exclamation-diamond-fill me-2 text-warning"></i> Peralatan Dengan Stok Rendah</h4>
    </div>

    <?php if (empty($peralatan)) : ?>
      <div class="alert alert-success text-center shadow-sm">
        Semua stok peralatan mencukupi. Tidak ada peralatan dengan stok rendah. 🎉
      </div>
    <?php else : ?>
      <div id="peralatanList" class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($peralatan as $p) : ?>
          <div class="col">
            <div class="card equipment-card card-glass h-100 p-3">
              <div class="card-body">
                <h5 class="card-title text-primary"><?= esc($p['nama']); ?></h5>
                <p class="mb-2"><strong>Kode:</strong> <?= esc($p['kode']); ?></p>
                <p class="mb-2"><strong>Ukuran:</strong> <?= esc($p['ukuran']); ?></p>
                <p class="mb-2">
                  <strong>Stok:</strong>
                  <span class="badge-low-stock"><?= esc($p['stok']); ?> tersisa</span>
                </p>
                <p class="mb-2"><strong>Keterangan:</strong> <?= esc($p['keterangan']); ?></p>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    document.getElementById('searchInput')?.addEventListener('input', function(e) {
      const search = e.target.value.toLowerCase();
      document.querySelectorAll("#peralatanList .equipment-card").forEach(function(card) {
        const text = card.innerText.toLowerCase();
        card.style.display = text.indexOf(search) > -1 ? '' : 'none';
      });
    });
  </script>
</body>
</html>
