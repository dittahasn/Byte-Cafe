<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" 
    href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/css/bootstrap.min.css">
    <title>Edit Peralatan</title>
</head>
<body class="container mt-5">
<h1>Edit Peralatan</h1>
<form action="/peralatan/update/<?= $peralatan['id']; ?>" method="POST">
    <input name="kode" placeholder="Kode" 
    value="<?= $peralatan['kode']; ?>" required class="form-control mb-2">
    <input name="nama" placeholder="Nama" 
    value="<?= $peralatan['nama']; ?>" required class="form-control mb-2">
    <input name="ukuran" placeholder="Ukuran" 
    value="<?= $peralatan['ukuran']; ?>" required class="form-control mb-2">
    <input name="stok" placeholder="Stok" 
    value="<?= $peralatan['stok']; ?>" required class="form-control mb-2">
    <select name="id_kategori" required class="form-control mb-2">
        <option disabled>Pilih Kategori</option>
        <?php foreach ($kategori as $kat): ?>
        <option value="<?= $kat['id']; ?>" <?= $kat['id']==$peralatan['id_kategori'] ? 'selected' : '' ?>> <?= $kat['nama_kategori']; ?> </option>
        <?php endforeach ?>
    </select>
    <textarea name="keterangan" 
    class="form-control mb-2"><?= $peralatan['keterangan']; ?></textarea>
    <button class="btn btn-primary" type="submit">Simpan</button>
</form>
</body>
</html>
