<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" 
    href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/css/bootstrap.min.css">
    <title>Tambah Peralatan</title>
</head>
<body class="container mt-5">
<h1>Tambah Peralatan</h1>
<form action="/peralatan/store" method="POST">
    <input name="kode" placeholder="Kode" required class="form-control mb-2">
    <input name="nama" placeholder="Nama" required class="form-control mb-2">
    <input name="ukuran" placeholder="Ukuran" required class="form-control mb-2">
    <input name="stok" placeholder="Stok" type="number" required class="form-control mb-2">
    <select name="id_kategori" required class="form-control mb-2">
        <option disabled selected>Pilih Kategori</option>
        <?php foreach ($kategori as $kat): ?>
        <option value="<?= $kat['id']; ?>"> <?= $kat['nama_kategori']; ?> </option>
        <?php endforeach ?>
    </select>
    <textarea name="keterangan" placeholder="Keterangan" 
    class="form-control mb-2"></textarea>
    <button class="btn btn-primary" type="submit">Simpan</button>
</form>
</body>
</html>
