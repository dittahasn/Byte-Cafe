<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Signup</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    html, body {
      height: 100%;
      background: linear-gradient(to right, #e0f7fa, #ffffff);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .centered-container {
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .card-glass {
      background: rgba(255, 255, 255, 0.85);
      backdrop-filter: blur(10px);
      border: none;
      border-radius: 20px;
      box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .form-control:focus {
      border-color: #0d6efd;
      box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
    }

    .btn-primary {
      border-radius: 10px;
      font-weight: 500;
      box-shadow: 0 4px 12px rgba(13, 110, 253, 0.3);
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 18px rgba(13, 110, 253, 0.4);
    }

    .form-label i {
      margin-right: 6px;
      color: #0d6efd;
    }

    a {
      color: #0d6efd;
      text-decoration: none;
    }

    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="centered-container">
    <div class="col-md-5 col-lg-4">
      <div class="card card-glass p-4">
        <h3 class="text-center fw-bold mb-4">
          <i class="bi bi-person-plus-fill me-2"></i>Signup
        </h3>

        <?php if (session('error')): ?>
          <div class="alert alert-danger"><?= session('error') ?></div>
        <?php endif; ?>

        <?php if (session('success')): ?>
          <div class="alert alert-success"><?= session('success') ?></div>
        <?php endif; ?>

        <form action="<?= base_url('/signup/register') ?>" method="POST">
          <?= csrf_field() ?>

          <div class="mb-3">
            <label for="username" class="form-label"><i class="bi bi-person-fill"></i>Username</label>
            <input
              id="username"
              name="username"
              type="text"
              class="form-control"
              placeholder="Enter your username"
              required
            >
          </div>

          <div class="mb-3">
            <label for="password" class="form-label"><i class="bi bi-lock-fill"></i>Password</label>
            <input
              id="password"
              name="password"
              type="password"
              class="form-control"
              placeholder="Enter your password"
              required
            >
          </div>

          <div class="mb-3">
            <label for="role" class="form-label"><i class="bi bi-person-badge-fill"></i>Role</label>
            <select id="role" name="role" class="form-select" required>
              <option value="">-- Select Role --</option>
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          <button type="submit" class="btn btn-primary w-100 mt-3">
            <i class="bi bi-check-circle-fill me-1"></i>Signup
          </button>
        </form>

        <p class="mt-4 mb-0 text-center text-muted">
          Already have an account?
          <a href="<?= base_url('/login') ?>">Login here</a>
        </p>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
