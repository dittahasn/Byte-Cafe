<!DOCTYPE html>
<html>
<head>
    <title>Edit Peralatan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2>Edit Peralatan</h2>
    <form action="<?= base_url('/peralatan/update/' . $item['id']) ?>" method="post">
        <?= csrf_field() ?>
        <div class="mb-3">
            <label>Kode</label>
            <input type="text" name="kode" class="form-control" value="<?= esc($item['kode']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="<?= esc($item['nama']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Kategori</label>
            <select name="id_kategori" class="form-select" required>
                <?php foreach ($kategori as $k): ?>
                    <option value="<?= $k['id'] ?>" <?= $item['id_kategori'] == $k['id'] ? 'selected' : '' ?>>
                        <?= esc($k['nama_kategori']) ?>
                    </option>
                <?php endforeach ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Ukuran</label>
            <input type="text" name="ukuran" class="form-control" value="<?= esc($item['ukuran']) ?>">
        </div>
        <div class="mb-3">
            <label>Stok</label>
            <input type="number" name="stok" class="form-control" value="<?= esc($item['stok']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Keterangan</label>
            <textarea name="keterangan" class="form-control"><?= esc($item['keterangan']) ?></textarea>
        </div>
        <button type="submit" class="btn btn-warning">Update</button>
        <a href="<?= base_url('peralatan') ?>" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
