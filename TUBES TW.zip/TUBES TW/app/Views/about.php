<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" 
    href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/css/bootstrap.min.css">
    <title>About</title>
</head>
<body class="container mt-5">
<h1>About Us</h1>
<div class="row">
    <?php foreach ($anggota as $a): ?>
    <div class="col-md-4">
        <div class="card mb-3 p-3">
            <img src="/images/<?= $a['foto']; ?>" alt="Foto" 
                 class="img-fluid mb-2">
            <h5><?= $a['nama']; ?></h5>
            <p>NIM: <?= $a['nim']; ?></p>
        </div>
    </div>
    <?php endforeach ?>
</div>
</body>
</html>
