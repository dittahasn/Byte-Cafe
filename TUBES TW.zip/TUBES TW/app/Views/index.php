<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Data Peralatan</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to right, #f0f4ff, #ffffff);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .navbar {
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    .navbar-brand {
      font-weight: bold;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .card-glass {
      background: #ffffffcc;
      backdrop-filter: blur(8px);
      border-radius: 16px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.06);
    }
    .low-stock {
      color: #dc3545;
      font-weight: bold;
    }
    .search-box input {
      border-radius: 30px;
      padding: 10px 20px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.06);
    }
    .btn-rounded {
      border-radius: 30px;
    }
    .table th, .table td {
      vertical-align: middle;
      padding: 12px 16px;
    }
    .table th {
      font-weight: 600;
      font-size: 0.95rem;
    }
    .table td {
      font-size: 0.93rem;
    }
    .btn-sm i {
      font-size: 0.9rem;
    }
    .table tbody tr:hover {
      background-color: #f7faff;
      transition: all 0.2s ease-in-out;
    }
    .card-header {
      border-top-left-radius: 16px;
      border-top-right-radius: 16px;
    }
    .section-title {
      font-size: 1.6rem;
      font-weight: 700;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="<?= base_url('/dashboard') ?>">Inventory App</a>
    <div class="ms-auto">
      <a href="<?= base_url('/logout') ?>" class="btn btn-outline-light btn-rounded">
        <i class="bi bi-box-arrow-right me-1"></i> Logout
      </a>
    </div>
  </div>
</nav>

<!-- Main Container -->
<div class="container py-5">

  <!-- Header -->
  <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
    <div>
      <h2 class="section-title"><i class="bi bi-archive me-2 text-primary"></i> Data Peralatan</h2>
      <p class="text-muted">Kelola dan pantau stok peralatan dengan mudah dan cepat.</p>
    </div>
    <div class="d-flex gap-2 mt-3 mt-md-0">
      <a href="<?= base_url('dashboard') ?>" class="btn btn-secondary btn-rounded">
        <i class="bi bi-arrow-left-circle me-1"></i> Kembali
      </a>
      <a href="<?= base_url('peralatan/create') ?>" class="btn btn-success btn-rounded">
        <i class="bi bi-plus-circle me-1"></i> Tambah Peralatan
      </a>
    </div>
  </div>

  <!-- Flash Message -->
  <?php if (session()->getFlashdata('success')) : ?>
    <div class="alert alert-success shadow-sm"><?= session()->getFlashdata('success') ?></div>
  <?php endif; ?>

  <!-- Search -->
  <div class="mb-4 search-box">
    <input id="searchInput" type="text" class="form-control" placeholder="🔍 Cari peralatan berdasarkan nama, kode, atau ukuran...">
  </div>

  <!-- Table Card -->
  <div class="card card-glass">
    <div class="card-header bg-primary text-white">
      <strong><i class="bi bi-table me-1"></i> Tabel Inventaris Peralatan</strong>
    </div>
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="align-middle text-center">
            <tr class="table-light">
              <th style="min-width: 90px;">Kode</th>
              <th>Nama</th>
              <th>Kategori</th>
              <th>Ukuran</th>
              <th>Stok</th>
              <th>Keterangan</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody id="tableBody">
            <?php foreach ($peralatan as $item): ?>
              <tr>
                <td class="text-center"><?= esc($item['kode']) ?></td>
                <td><?= esc($item['nama']) ?></td>
                <td><?= esc($item['nama_kategori']) ?></td>
                <td class="text-center"><?= esc($item['ukuran']) ?></td>
                <td class="text-center <?= ($item['stok'] < 5) ? 'low-stock' : '' ?>">
                  <?= esc($item['stok']) ?>
                </td>
                <td><?= esc($item['keterangan']) ?></td>
                <td class="text-center">
                  <a href="<?= base_url('peralatan/edit/' . $item['id']) ?>" class="btn btn-sm btn-outline-warning me-1" title="Edit">
                    <i class="bi bi-pencil-fill"></i>
                  </a>
                  <form action="<?= base_url('peralatan/delete/' . $item['id']) ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Hapus">
                      <i class="bi bi-trash-fill"></i>
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // Search filter
  document.getElementById('searchInput')?.addEventListener('input', function () {
    const search = this.value.toLowerCase();
    const rows = document.querySelectorAll('#tableBody tr');
    rows.forEach(row => {
      const text = row.innerText.toLowerCase();
      row.style.display = text.includes(search) ? '' : 'none';
    });
  });
</script>

</body>
</html>
