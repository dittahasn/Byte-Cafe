<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Daftar Peralatan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(135deg, #edf2ff, #ffffff);
      font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .header-section {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
      flex-wrap: wrap;
    }
    .header-section h2 {
      color: #0d6efd;
      font-weight:bold;
    }
    .table-card {
      background: #ffffffcc;
      backdrop-filter: blur(10px);
      border-radius: 24px;
      box-shadow: 0 10px 30px rgb(0 0 0 / 10%)
    }
    .table-card tbody tr {
      transition: all 0.3s ease;
    }
    .table-card tbody tr:hover {
      background: #edf2ff;
      transform: translateY(-2px);
    }
    .table-card thead {
      background: #edf2ff;
      color: #0d6efd;
    }
    .badge-stok {
      padding: 6px 14px;
      border-radius: 999px;
      color: #ffffff;
      font-size: 0.85rem;
      font-weight: 500;
    }
    .badge-stok.red {
      background: linear-gradient(45deg, #ff416c, #ff4b2b);
      box-shadow: 0 4px 10px rgb(255 65 108 / 30%)
    }
    .badge-stok.green {
      background: linear-gradient(45deg, #00c851, #007bff);
      box-shadow: 0 4px 10px rgb(0 200 81 / 30%)
    }
    .print-button {
      transition: all 0.3s ease;
      background: linear-gradient(45deg, #0d6efd, #6610f2);
      border: none;
      color: #ffffff;
      box-shadow: 0 4px 12px rgb(13 110 253 / 40%)
    }
    .print-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgb(13 110 253 / 60%)
    }
    @media print {
      .no-print {
        display: none;
      }
    }
  </style>
</head>
<body>

  <div class="container py-5">
    <div class="header-section">
      <h2><i class="bi bi-clipboard-fill me-2"></i> Daftar Peralatan</h2>
      <button class="btn print-button no-print" onclick="window.print()"> 
        <i class="bi bi-printer-fill me-1"></i> Cetak
      </button>
    </div>

    <div class="table-responsive">
      <table class="table table-bordered table-card align-middle">
        <thead>
          <tr>
            <th><i class="bi bi-upc-scan me-1"></i>Kode</th>
            <th><i class="bi bi-toolbox-fill me-1"></i>Nama</th>
            <th><i class="bi bi-tags-fill me-1"></i>Kategori</th>
            <th><i class="bi bi-arrows-fullscreen me-1"></i>Ukuran</th>
            <th><i class="bi bi-box-fill me-1"></i>Stok</th>
            <th><i class="bi bi-info-circle-fill me-1"></i>Keterangan</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($peralatan as $item): ?>
            <tr>
              <td><?= esc($item['kode']) ?></td>
              <td><?= esc($item['nama']) ?></td>
              <td><?= esc(isset($item['nama_kategori']) ? $item['nama_kategori'] : 'nama_kategori') ?></td>
              <td><?= esc($item['ukuran']) ?></td>
              <td>
                <span class="badge-stok <?= ($item['stok'] <= 5) ? 'red' : 'green' ?>"> 
                   <?= esc($item['stok']) ?>
                </span>
              </td>
              <td><?= esc($item['keterangan']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>