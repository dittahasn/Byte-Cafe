<?php

use CodeIgniter\Router\RouteCollection;
use App\Controllers\Login;
use App\Controllers\Signup;
use App\Controllers\Peralatan;
use App\Controllers\About;
use App\Controllers\API;
use App\Controllers\Dashboard;

/**
 * @var RouteCollection $routes
 */

// Default route
$routes->get('/', [Signup::class, 'index']);  // Halaman awal ke login

// ==============================
// AUTH ROUTES
// ==============================

$routes->get('/login', [Login::class, 'index']);
$routes->post('/login/process', [Login::class, 'process']);
$routes->get('/login/logout', [Login::class, 'logout']); // opsional jika ada logout

$routes->get('/signup', [Signup::class, 'index']);
$routes->post('/signup/process', [Signup::class, 'register']);


// ==============================
// DASHBOARD
// ==============================

$routes->get('/dashboard', [Dashboard::class, 'index']);


// ==============================
// CRUD PERALATAN
// ==============================

$routes->get('/peralatan', [Peralatan::class, 'index']);
$routes->get('/peralatan/create', [Peralatan::class, 'create']);
$routes->post('/peralatan/store', [Peralatan::class, 'store']);
$routes->get('/peralatan/edit/(:num)', [Peralatan::class, 'edit/$1']);
$routes->post('/peralatan/update/(:num)', [Peralatan::class, 'update/$1']);
$routes->post('/peralatan/delete/(:num)', [Peralatan::class, 'delete/$1']); // GANTI dari GET ke POST untuk keamanan


// ==============================
// ABOUT
// ==============================

$routes->get('/about', [About::class, 'index']);


// ==============================
// REST API ROUTES
// ==============================

$routes->get('/api/peralatan', [API::class, 'index']);
$routes->get('/api/peralatan/(:num)', [API::class, 'show/$1']);
$routes->post('/api/peralatan', [API::class, 'create']);
$routes->put('/api/peralatan/(:num)', [API::class, 'update/$1']);
$routes->delete('/api/peralatan/(:num)', [API::class, 'delete/$1']);
$routes->get('/logout', 'Auth::logout');


$routes->get('/cetak', [Peralatan::class, 'cetak']);